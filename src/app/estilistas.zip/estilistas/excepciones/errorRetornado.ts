export class ErrorRetornado
 {  
    codigoError!: string;
    mensaje!: string;
    codigoHttp!: number;
    url!: string;
    metdo!: string;
}
