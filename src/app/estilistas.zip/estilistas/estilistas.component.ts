import { Component } from '@angular/core';

@Component({
  selector: 'app-estilistas',
  standalone: true,
  imports: [],
  templateUrl: './estilistas.component.html',
  styleUrl: './estilistas.component.css'
})
export class EstilistasComponent {

}